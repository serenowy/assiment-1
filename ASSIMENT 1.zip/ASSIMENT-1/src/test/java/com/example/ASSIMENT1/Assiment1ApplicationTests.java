package com.example.ASSIMENT1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assiment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
