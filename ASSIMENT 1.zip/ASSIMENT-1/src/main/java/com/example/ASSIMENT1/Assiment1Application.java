package com.example.ASSIMENT1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assiment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assiment1Application.class, args);
	}

}
